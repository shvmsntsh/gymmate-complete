<template>
  <v-app>
    <v-container fluid class="pa-0 fill-height">
      <v-row no-gutters class="fill-height">
        <!-- Left Panel -->
        <v-col cols="12" md="6" class="gradient-blue d-flex flex-column align-center justify-center text-white pa-12">
          <h2 class="text-h3 font-weight-bold mb-2">Welcome Back!</h2>
          <p class="text-subtitle-1 mb-6">Already have an account? Sign in here.</p>
          <v-btn color="white" class="text-blue-darken-3" rounded="xl" size="large">
            SIGN IN
          </v-btn>
        </v-col>

        <!-- Right Panel -->
        <v-col cols="12" md="6" class="pa-12 d-flex align-center justify-center">
          <v-card elevation="8" class="w-100" max-width="500">
            <v-card-title class="text-h5 font-weight-medium justify-center">
              Just a few more details
            </v-card-title>
            <v-card-text>
              <v-form @submit.prevent="submit">
                <v-text-field v-model="form.name" label="Gym Name" variant="outlined" />
                <v-text-field v-model="form.email" type="email" label="Email" variant="outlined" />
                <v-text-field v-model="form.password" type="password" label="Password" variant="outlined" />
                <v-text-field v-model="form.address" label="Address" variant="outlined" />
                <v-text-field v-model="form.contactNumber" label="Contact Number" variant="outlined" />
                <v-text-field v-model="form.services" label="Services (comma-separated)" variant="outlined" />
                <v-row class="mt-6" justify="space-between">
                  <v-btn variant="outlined" color="grey">BACK</v-btn>
                  <v-btn type="submit" color="primary" dark>SIGN UP</v-btn>
                </v-row>
              </v-form>
            </v-card-text>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </v-app>
</template>

<script setup>
import { ref } from 'vue'
const form = ref({
  name: '', email: '', password: '', address: '', contactNumber: '', services: ''
})

async function submit () {
  const payload = {
    ...form.value,
    services: form.value.services.split(',').map(s => s.trim())
  }

  try {
    const res = await fetch('http://localhost:5050/api/gym/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
    const data = await res.json()
    alert(data.message || 'Registered!')
  } catch (err) {
    console.error(err)
    alert('Registration failed')
  }
}
</script>

<style scoped>
.gradient-blue {
  background: linear-gradient(135deg, #4a90e2, #145cff);
}
</style>